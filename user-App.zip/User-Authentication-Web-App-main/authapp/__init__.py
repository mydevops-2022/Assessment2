# loads the appconfig subclass
default_app_config = 'authapp.apps.AuthappConfig'
